# Importar librerias necesarias
from flask import Flask, render_template, request, redirect
import openai
import os
import time


# Establecer la clave API de OpenAI

openai.api_key = "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"

# Definir el nombre de bot
name = 'Asistente Virtual del profesor Omar Cruz'

# Definir el rol del bot
role = 'Profesor Virtual'

# Entrena al bot
impersonated_role = f"""
    From now on, you are going to act as {name}. Your role is {role}.
    You are a true impersonation of {name} and you reply to all requests with I pronoun. You never give unknown information.
    Answer only questions about school topics. only computer science.
    YOU ARE NOT AN AI MODEL!
"""

# Inicia las variable para el historial del chat
explicit_input = ""
chatgpt_output = 'Chat log: /n'
cwd = os.getcwd()
i = 1

# FEncontrar el archivo del historial del chat
while os.path.exists(os.path.join(cwd, f'chat_history{i}.txt')):
    i += 1

history_file = os.path.join(cwd, f'chat_history{i}.txt')

# Crear un nuevo archivo de historial de chat
with open(history_file, 'w') as f:
    f.write('\n')

# Iniciar el historiial del chat
chat_history = ''

# Crear la aplicacion con flask
app = Flask(__name__)

# Función para completar la entrada del chat usando GPT-3.5 de OpenAI
def chatcompletion(user_input, impersonated_role, explicit_input, chat_history):
    output = openai.ChatCompletion.create(
        model="gpt-3.5-turbo-0301",
        temperature=1,
        presence_penalty=0,
        frequency_penalty=0,
        max_tokens=2000,
        messages=[
            {"role": "system", "content": f"{impersonated_role}. Conversation history: {chat_history}"},
            {"role": "user", "content": f"{user_input}. {explicit_input}"},
        ]
    )

    for item in output['choices']:
        chatgpt_output = item['message']['content']

    return chatgpt_output

# Función para manejar la entrada del chat del usuario
def chat(user_input):
    global chat_history, name, chatgpt_output
    current_day = time.strftime("%d/%m", time.localtime())
    current_time = time.strftime("%H:%M:%S", time.localtime())
    chat_history += f'\nUser: {user_input}\n'
    chatgpt_raw_output = chatcompletion(user_input, impersonated_role, explicit_input, chat_history).replace(f'{name}:', '')
    chatgpt_output = f'{name}: {chatgpt_raw_output}'
    chat_history += chatgpt_output + '\n'
    with open(history_file, 'a') as f:
        f.write('\n'+ current_day+ ' '+ current_time+ ' User: ' +user_input +' \n' + current_day+ ' ' + current_time+  ' ' +  chatgpt_output + '\n')
        f.close()
    return chatgpt_raw_output

# Función para obtener respuesta del chatbot
def get_response(userText):
    return chat(userText)

# Definir rutas de aplicaciones
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/get")
# Función para la respuesta del bot.
def get_bot_response():
    userText = request.args.get('msg')
    return str(get_response(userText))

@app.route('/refresh')
def refresh():
    time.sleep(600) # esperar 10 Minutos
    return redirect('/refresh')

# Iniciar la app de Flask
if __name__ == "__main__":
    app.run()
